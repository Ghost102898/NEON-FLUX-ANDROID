# NEON FLUX Android — Fase 2

Proyecto de empaquetado de NEON FLUX v1.2 para Android usando Capacitor. El juego original está en `www/index.html`.

## Requisitos
- Node.js 22+
- Java 21
- Android SDK / Android Studio (o runner de GitHub Actions)

## Preparar Android
```bash
npm install
npx cap add android
npx cap sync android
```

## Compilar APK debug
```bash
cd android
./gradlew assembleDebug
```

APK esperado: `android/app/build/outputs/apk/debug/app-debug.apk`.

La versión actual conserva los anuncios simulados del prototipo. La integración real de Google AdMob y compras opcionales queda para una fase posterior.
