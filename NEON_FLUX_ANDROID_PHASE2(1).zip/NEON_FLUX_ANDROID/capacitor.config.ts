import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ghost.neonflux',
  appName: 'NEON FLUX',
  webDir: 'www',
  backgroundColor: '#070914'
};

export default config;
